import { type ReactNode } from 'react';
export { RibbonButton, type RibbonButtonProps } from './RibbonButton';
export { RibbonNumber, type RibbonNumberProps } from './RibbonNumber';
export { RibbonSlot } from './RibbonSlot';
export type { RibbonSize } from './ribbonSizes';
/** The bar itself: a full-height row of sections with dividers between them. */
export declare function Ribbon({ children, className }: {
    children: ReactNode;
    className?: string;
}): import("react").JSX.Element;
/**
 * A titled group: the item area on top, a tinted full-width title band
 * underneath that reads as the group's footer in both themes.
 * Children declare a `size` (big = 1 per column, medium = 2, mini = 3); the
 * section packs them into columns in order, and a column that is not
 * completely full centres its content vertically. A column is as wide as its
 * widest item; with `fill`, a title wider than the items is shared out among
 * the columns, so the buttons span the whole section.
 * The size is read off each DIRECT child element's props (a RibbonSlot or
 * RibbonNumber without one packs as the `medium` it draws, anything else as
 * `big`), so a component that wraps a RibbonButton must take `size` as its
 * own prop — a size decided inside it is invisible here.
 */
export declare function RibbonSection({ title, children, fill, className, }: {
    title: ReactNode;
    children: ReactNode;
    /** Stretch the columns to the section's width when the title is wider than
     *  the items (default: columns keep their content width). */
    fill?: boolean;
    className?: string;
}): import("react").JSX.Element;
