import { type MenuEntry } from './menuTypes';
export type { MenuEntry, MenuItem, MenuSeparator } from './menuTypes';
export interface MenuProps {
    /** Viewport coordinates of the press that opened it; null renders nothing. */
    anchor: Readonly<{
        x: number;
        y: number;
    }> | null;
    /** Entries in order; falsy entries are skipped, `{ separator: true }` draws a rule. */
    items: readonly MenuEntry[];
    /** An outside press, Escape and a pick all call this — clear `anchor` here. */
    onClose: () => void;
    /** Width floor in px (default 160) — keeps a short menu from looking cramped. */
    minWidth?: number;
    /** Entry id to focus when the menu opens (say the current choice) — for a
     *  menu opened from the keyboard. Escape or a pick then hands focus back to
     *  where it was. */
    focusId?: string;
    className?: string;
}
/**
 * A right-click menu, portaled to the body so panel scroll clipping can never
 * cut it off. It opens at the press position and is then measured and nudged
 * back inside the viewport — no hard-coded size guesses. Closes on any outside
 * press, on Escape, and after a pick. While focus is inside, the arrow keys
 * move between entries.
 */
export declare function Menu({ anchor, items, onClose, minWidth, focusId, className }: MenuProps): import("react").ReactPortal | null;
